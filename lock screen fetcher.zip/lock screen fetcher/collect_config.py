# The path defined below is the path which collect.py will target
# If collect_from is undefined, then collect will default to current dir.
collect_from = 'C:\\Users\\mikae\\AppData\\Local\\Packages\\Microsoft.Windows.ContentDeliveryManager_cw5n1h2txyewy\\LocalState\\Assets'
